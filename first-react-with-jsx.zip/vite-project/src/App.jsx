function App() {
  return (
    <div>
      <h1>Hello Dojo</h1>
      <h2>Things I need to do:</h2>
      <ul>
        <li>Learn React</li>
        <li>Build Projects</li>
        <li>Master JSX</li>
        <li>Deploy a React App</li>
      </ul>
    </div>
  );
}

export default App;
